import java.awt.*;  // import the AWT graphic classes
import javax.swing.*;   // import the Swing classes

/**
 * LayoutGUI class 
 *
 * @author Cathy Bishop
 *
 * On my honor, as a Carnegie-Mellon Africa student, I have neither given nor received unauthorized assistance.
 *
 */

public abstract class LayoutGUI extends JPanel
{
    public abstract void addComponents(JFrame theFrame);
}